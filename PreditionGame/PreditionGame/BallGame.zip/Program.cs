﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreditionGame
{
    class Program
    {
        static void Main(string[] args)
        {
            //Get the Level
            //Initialize the ball and containers
            BallGame _game = new BallGame();
            _game.InitializeGame(4);
            //Get the predictions 
            //Play game
            int _emptyContainer=_game.Play();
            // Comapre the input with result
            //Display message

        }
    }
}
